package com.oceanview.character_selection_test;


import android.widget.TextView;

import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.IgnoreExtraProperties;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.ValueEventListener;

@IgnoreExtraProperties
public class Character {

        //Declare Instance Variables
        private int level;
        private String name;



        /////////////////////////////



        //Constructors

        //Creates a new character in the first available character slot
        // fails if there are no slots
        Character() {
            name = "John Doe";
            level = 0;

        }

        //Get Set Methods

        public String getName(){return name;}
        public void setName(String Name) {name = Name;}

        public int getLevel(){return level;}
        public void setLevel(int Level){level = Level;}




    }

