package com.oceanview.character_selection_test;

import android.content.ClipData;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputLayout;
import android.support.v7.view.menu.MenuView;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener , View.OnClickListener {




    Character character;
    TextView txt;
    EditText editText;
    Button next;

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference reference;
    DatabaseReference characterReference;
    final static String TAG = "DatabaseUseActivity";
    private int count = 1;


    //START OF PROGRAM//////////////////////////////////

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        //Set Up Elements///
        txt = findViewById(R.id.txt);
        editText = findViewById(R.id.editText);
        editText.setVisibility(View.INVISIBLE);
        next = findViewById(R.id.submit);
        next.setVisibility(View.INVISIBLE);
        /////////////////////


        //FLOATING ACTION BAR STUFF, IGNORE
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        /////////////////////////////////////


        //Drawer Stuff, Ignore
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        final NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        ///////////////////////////////

        //Character names added to Drawer slot names if available

        characterReference = database.getReference("users/testperson/characters");
        characterReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                MenuItem item =  navigationView.getMenu().findItem(R.id.nav_1);
                if (dataSnapshot.child("1").hasChild("name")){

                    item.setTitle(dataSnapshot.child("1").child("name").getValue(String.class) );
                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });




        ////


      //  character = new Character();
      //  characterReference = database.getReference("users/testperson/characters/1");
      //  characterReference.setValue(character);

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_1) {
            loadCharacter(1);

        } else if (id == R.id.nav_2) {
            loadCharacter(2);
        } else if (id == R.id.nav_3) {
            loadCharacter(3);
        } else if (id == R.id.nav_4) {
             loadCharacter(4);
        } else if (id == R.id.nav_edit) {
            editCharacter();
        } else if (id == R.id.nav_new) {
            createCharacter();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.submit:
                submitData();


        }

    }


    private void loadCharacter(int slot){

        characterReference = database.getReference("users/testperson/characters/"+slot);
        characterReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                character = dataSnapshot.getValue(Character.class);
                txt.setText("Hello "+character.getName());
                Log.d(TAG, "Sucess: " + character);


            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.w(TAG, "Failed to read value.", databaseError.toException());
              }
        });



    }

    private void editCharacter(){
        editText.setText("This button has no functionality currently, Just overwrite an existing character instead");
    }


    /**
     * works with submitData to create a new character and upload it to the cloud
     */
    private void createCharacter(){


        if (count == 1){
            //Set up text edit
            editText.setVisibility(View.VISIBLE);
            editText.setInputType(InputType.TYPE_CLASS_TEXT);
            editText.setText("Name");
            /////////////////////

            //Set up Submit Button
            next.setVisibility(View.VISIBLE);
            next.setOnClickListener(this);


            txt.setText("Enter Your Name");

            character = new Character();

        }
        if (count == 2){
            //Set up text edit
            editText.setText("");
            editText.setInputType(InputType.TYPE_CLASS_NUMBER);
            //////////////////


            txt.setText("Enter slot to save to");

        }


    }
    private void submitData(){

       if(count == 1) {
           character.setName(editText.getText().toString());
           txt.setText(character.getName());
           count++;

           createCharacter();
       }
       if (count == 2) {
           String temp = editText.getText().toString();
            if (temp.equals("1") || temp.equals("2") || temp.equals("3") || temp.equals("4")){
                characterReference = database.getReference("users/testperson/characters/"+temp);
                characterReference.setValue(character);
                next.setVisibility(View.INVISIBLE);
                editText.setVisibility(View.INVISIBLE);
                txt.setText("Hello "+ character.getName());
                count = 1;
            }


       }
    }

}
